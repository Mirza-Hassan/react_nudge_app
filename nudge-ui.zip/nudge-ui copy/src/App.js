import MainContainer from "./containers/Main";

function App() {
  return (
    <div className="App">
      <MainContainer />
    </div>
  );
}

export default App;
