import React from "react";
import {Select} from "antd";
import {Button, Tooltip} from "antd";
import {SearchOutlined} from "@ant-design/icons";

const Header = (props) => {
  const {monthChange, weekChange, searchHandler} = props;
  const {Option} = Select;

  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  const weeks = ["Wk1", "Wk2", "Wk3", "Wk4", "Wk5"];

  const valueChange = () => {
    console.log("search called");
    searchHandler();
  };
  return (
    <>
      <Select
        size="large"
        dropdownMatchSelectWidth
        showSearch
        placeholder="Select a month"
        optionFilterProp="children"
        onChange={monthChange}
        filterOption={(input, option) =>
          option.children.toLowerCase().includes(input.toLowerCase())
        }
      >
        {months.map((month) => (
          <Option key={month} value={month}>
            {month}
          </Option>
        ))}
      </Select>
      <Select
        size="large"
        showSearch
        placeholder="Select a week"
        optionFilterProp="children"
        onChange={weekChange}
        filterOption={(input, option) =>
          option.children.toLowerCase().includes(input.toLowerCase())
        }
      >
        {weeks.map((week) => (
          <Option key={week} value={week}>
            {week}
          </Option>
        ))}
      </Select>
      <Tooltip title="search">
        <Button
          type="primary"
          shape="circle"
          icon={<SearchOutlined />}
          onClick={searchHandler}
        />
      </Tooltip>
    </>
  );
};

export default Header;
