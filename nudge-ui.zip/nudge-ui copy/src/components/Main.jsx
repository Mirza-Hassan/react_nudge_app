import React, {useEffect, useState} from "react";
// import {Button, Descriptions, PageHeader, Row, Statistic, Tag} from "antd";
import {Segmented} from "antd";

import {MainContainer} from "./styles/styles";
import "antd/dist/antd.css";

import Entries from "./Entries";

import styles from "./styles/main.module.scss";
import Header from "./Header";
import PieChart from "./HoursChart";
import Dashboard from "./Dashboard";

const Main = (props) => {
  const {monthChange, weekChange, searchHandler} = props;
  const [entryType, setEntryType] = useState("All");
  const {entries} = props;

  const handleChange = (params) => {
    console.log("params ", params);
    setEntryType(params);
  };

  const entriesInfo =
    entries &&
    entries.reduce(
      (preValue, currentValue, idx, entries) => {
        console.log("preValue ", preValue);

        preValue.pending =
          currentValue.status === "Pending"
            ? preValue.pending + 1
            : preValue.pending;

        preValue.approved =
          currentValue.status === "Approved"
            ? preValue.approved + 1
            : preValue.approved;

        preValue.missing =
          currentValue.status === "" ? preValue.missing + 1 : preValue.missing;

        return preValue;
      },
      {pending: 0, missing: 0, approved: 0}
    );

  console.log("entriesInfo ", entriesInfo);

  console.log("javed:: rendering...", entryType);
  return (
    <MainContainer>
      <div className={styles.header}>
        <Header
          monthChange={monthChange}
          weekChange={weekChange}
          searchHandler={searchHandler}
        />
      </div>

      <div className={styles.tabs}>
        <Segmented
          block
          options={["Dashboard", "All"]}
          defaultValue="All"
          onChange={handleChange}
        />
        {entryType === "Dashboard" && entries?.length > 0 && (
          <Dashboard entries={entriesInfo} />
        )}
        {entryType === "All" && <Entries name={entryType} entries={entries} />}
      </div>
    </MainContainer>
  );
};

export default Main;
