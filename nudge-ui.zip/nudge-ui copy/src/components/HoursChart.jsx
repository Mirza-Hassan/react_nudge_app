import React from "react";
import {Pie} from "@ant-design/plots";
import styles from "./styles/main.module.scss";

const HoursChart = (props) => {
  const {entries} = props;
  const data = [
    {
      type: "Pending",
      value: entries.pending,
    },
    {
      type: "Missing",
      value: entries.missing,
    },
    {
      type: "Approved",
      value: entries.approved,
    },
  ];
  const config = {
    appendPadding: 10,
    data,
    angleField: "value",
    colorField: "type",
    color: ["#E6B325", "#fd5c63", "#7FB77E"],
    radius: 0.9,
    label: {
      type: "inner",
      offset: "-30%",
      content: ({percent}) => `${(percent * 100).toFixed(0)}%`,
      style: {
        fontSize: 14,
        textAlign: "center",
      },
    },
    interactions: [
      {
        type: "element-active",
      },
    ],
  };
  return (
    <div className={styles.hours}>
      <Pie {...config} />
    </div>
  );
};

export default HoursChart;
