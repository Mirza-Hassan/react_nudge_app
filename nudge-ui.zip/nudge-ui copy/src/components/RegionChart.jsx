import React from "react";
import {Pie} from "@ant-design/plots";
import styles from "./styles/main.module.scss";

const RegionChart = () => {
  const data = [
    {
      type: "Pakistan",
      value: 80,
    },
    {
      type: "India",
      value: 2,
    },
    {
      type: "Chile",
      value: 5,
    },
    {
      type: "US",
      value: 13,
    },
  ];
  const config = {
    appendPadding: 10,
    data,
    angleField: "value",
    colorField: "type",
    color: ["#115740", "#FF9933", "#DA291C", "#0A3161"],
    radius: 0.9,
    label: {
      type: "inner",
      offset: "-30%",
      content: ({percent}) => `${(percent * 100).toFixed(0)}%`,
      style: {
        fontSize: 14,
        textAlign: "center",
      },
    },
    interactions: [
      {
        type: "element-active",
      },
    ],
  };
  return (
    <div className={styles.hours}>
      <Pie {...config} />
    </div>
  );
};

export default RegionChart;
