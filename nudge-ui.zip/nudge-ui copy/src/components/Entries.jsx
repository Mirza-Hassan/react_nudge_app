import React from "react";
import {Table, Space, Tag} from "antd";
import styles from "./styles/entry.module.scss";

const Entries = (props) => {
  const columns = [
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (v) => {
        let color = "#7FB77E";
        if (v === "Pending") color = "#E6B325";

        if (v === "") {
          color = "#fd5c63";
          v = "MISSING";
        }

        return (
          <Tag color={color} key={v}>
            {v.trim().toUpperCase()}
          </Tag>
        );
      },
    },
    {
      title: "Hours",
      dataIndex: "hours",
      key: "hours",
    },
    {
      title: "Actions",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <a>Reminder</a>
          <a>Email</a>
        </Space>
      ),
    },
  ];

  return (
    <div>
      <Table
        dataSource={props.entries}
        columns={columns}
        pagination={{
          position: ["none", "bottomCenter"],
        }}
      />
    </div>
  );
};

export default Entries;
