import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;

  width: 70%;
  background-color: #f4f4f4;
  box-shadow: 5px 7px 11px -2px rgba(194, 191, 191, 0.75);
  -webkit-box-shadow: 5px 7px 11px -2px rgba(194, 191, 191, 0.75);
  -moz-box-shadow: 5px 7px 11px -2px rgba(194, 191, 191, 0.75);
`;
