import React from "react";
import PieChart from "./HoursChart";
import RegionChart from "./RegionChart";
import styles from "./styles/main.module.scss";

const Dashboard = (props) => {
  const {entries} = props;
  return (
    <div className={styles.dashboard}>
      <PieChart entries={entries} />
      <RegionChart />
    </div>
  );
};

export default Dashboard;
