import styled from "styled-components";

export const MainContainer = styled.div`
  background-color: #f1f5f5;
  box-sizing: border-box;
  width: 100vw;
  height: 100%;
  display: flex;
  justify-content: center;

  & tr:hover {
    background-color: none;
  }
`;
