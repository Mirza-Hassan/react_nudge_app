import {useState} from "react";
import Home from "../components/Main";
import {MainContainer} from "./styles";

const Main = (props) => {
  const [entries, setEntries] = useState([]);
  const [month, setMonth] = useState("");
  const [week, setWeek] = useState("");

  const searchHandler = () => {
    month &&
      week &&
      fetch(
        `http://localhost:8000/billing/s37/entries/missing?month=${month}&week=${week}`
      )
        .then((response) => response.json())
        .then((data) => {
          setEntries(data);
        })
        .catch((error) => {
          console.error("Error:", error);
        });
  };

  return (
    <MainContainer>
      <Home
        entries={entries}
        monthChange={setMonth}
        weekChange={setWeek}
        searchHandler={searchHandler}
      ></Home>
    </MainContainer>
  );
};

export default Main;
