var express = require("express");
const Util = require("./parsers/Util");

const BillingSheet = require("./parsers/BillingSheet");
const fs = require("fs");

var router = express.Router();

const isValidWeek = (week) => {
  if (!week || !week?.length > 0) return false;

  return week.match(/^[W]{1}[k]{1}[1-4]$/) ? true : false;
};

const isValidMonth = (month) => {
  if (!month || !month?.length > 0) return false;

  return true;
  // return month.match(/^[W]{1}[k]{1}\d$/) ? true : false;
};

/* GET users listing. */
router.get("/s37/entries/missing", async function (req, res, next) {
  // Science37 billing sheet

  let month = req.query.month;
  let week = req.query.week;
  if (!month || !month?.length > 0) {
    res.status(400).send({
      status: 400,
      message:
        "invalid month, please provide valid month query param, i.e. month=Jan",
    });
    return;
  }
  if (!isValidWeek(week)) {
    res.status(400).json({
      status: 400,
      message:
        "invalid week, please proive valid week query param, i.e. week=Wk1",
    });
    return;
  }

  const localCache = req.app.locals.cache;
  let data = [];
  if (!localCache.has("data")) {
    const billingData = await new Util().read(this.spreadsheetId);
    data = billingData?.data?.values;

    console.log("the cache does not have data, so setting data in the cache");
    localCache.set("data", data, 10000);
  } else {
    console.log("the data exists in the cache, so reading from the cache");
    data = localCache.get("data");
  }

  const billingSheet = new BillingSheet();
  const parser = billingSheet.getParser("s37", data);

  const missedEntries = await parser.findMissingEntries(month, week);
  res.send(JSON.stringify(missedEntries));
});

module.exports = router;
