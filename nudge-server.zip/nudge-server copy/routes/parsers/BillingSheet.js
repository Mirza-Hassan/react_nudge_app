const Science37Parser = require("./s37/Parser");
module.exports = class BillingSheet {
  getParser = (clientName, data) => {
    console.log("clientName ", clientName);
    if ("s37" == clientName) {
      console.log("returning s37 parser ");
      return new Science37Parser(data);
    }
  };
};
