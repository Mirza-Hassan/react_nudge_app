//googleapis
const {google} = require("googleapis");

module.exports = class Util {
  read = async (sheetId) => {
    const auth = new google.auth.GoogleAuth({
      keyFile: "nisum-nudge.json", //the key file
      //url to spreadsheets API
      scopes: "https://www.googleapis.com/auth/spreadsheets",
    });
    const authClientObject = await auth.getClient();
    const googleSheetsInstance = google.sheets({
      version: "v4",
      auth: authClientObject,
    });

    // individual sheet
    //  const spreadsheetId = "1WFVfRrtJ58SR7i4_mEFBXrJ7jOuuEBNk01zp5Xh27Gk";
    const spreadsheetId = "1dg2yww_WqPCOQGDAl4-q6LEXOd6GbhE2x8ezUNYaROo";

    const readData = await googleSheetsInstance.spreadsheets.values.get({
      auth, //auth object
      spreadsheetId, // spreadsheet id

      //individual range
      // range: "Wk1!A:K", //range of cells to read from.

      range: "Timecard - 2022!A:CA", //range of cells to read from.

      // range: "Timecard - 2022!BT:BU", //range of specific window.
    });
    return readData;
  };
};
