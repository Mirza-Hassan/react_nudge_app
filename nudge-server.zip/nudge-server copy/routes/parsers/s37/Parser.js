module.exports = class Science37 {
  constructor(data) {
    this.spreadsheetId = "1dg2yww_WqPCOQGDAl4-q6LEXOd6GbhE2x8ezUNYaROo";
    this.data = data;
    this.monthInitials = [
      "Jan",
      "Feb",
      "Mar",

      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
  }

  extractMonthsInfo = () => {
    const months = this.data[1];

    const monthsInfo = this.monthInitials.map((month, idx) => {
      const startIdx = months?.findIndex((e) => e.includes(month));
      if (startIdx <= 0) return;
      const endIdx =
        idx + 1 <= this.monthInitials.length
          ? months?.findIndex((e) => e.includes(this.monthInitials[idx + 1])) -
            1
          : 0;
      return {month, startIdx, endIdx};
    });
    return monthsInfo;
  };

  extractWeeksInfo = (monthsInfo) => {
    let tempMonthsInfo = [];
    const weeks = this.data[2];
    // console.log("monthinfo ", monthsInfo);
    // console.log("monthinfo ", weeks);

    const weeksInfo = monthsInfo.map((m) => {
      const startingWkIdx = m.startIdx;
      const startingWk = weeks[startingWkIdx];
      const weeksInfo = [
        {
          week: startingWk,
          startIdx: startingWkIdx,
          endIdx: startingWkIdx + 1,
        },
      ];
      const endIdx = m.endIdx >= 0 ? m.endIdx + 1 : weeks.length;
      for (let i = startingWkIdx + 2; i <= endIdx; i + 2) {
        const week = weeks[i];
        if (week.includes("1")) {
          break;
        }
        const weekObj = {week, startIdx: i, endIdx: i + 1};
        weeksInfo.push(weekObj);
        i += 2;
      }
      tempMonthsInfo.push({...m, weeks: weeksInfo});
    });
    return tempMonthsInfo;
  };

  findMissingEntries = async (month, week) => {
    const monthsInfo = this.extractMonthsInfo();
    const completeInfo = this.extractWeeksInfo(
      monthsInfo.filter((m) => m != undefined)
    );

    const entries = this.data?.slice(4, 100);
    const monthAndWeekInfo = completeInfo.find((o) => o.month === month);
    const weekEntry = monthAndWeekInfo["weeks"].find((w) => w.week === week);
    console.log(
      "🚀 ~ file: Parser.js ~ line 78 ~ Science37 ~ findMissingEntries= ~ weekEntry",
      weekEntry
    );

    const reducer = (entries = [], entry) => {
      const name = entry[0];
      const status =
        entry[weekEntry.startIdx] == "Pending" ||
        entry[weekEntry.startIdx] == "Approved"
          ? entry[weekEntry.startIdx]
          : "";
      const hours = entry[weekEntry.endIdx] >= 0 ? entry[weekEntry.endIdx] : 0;
      entries.push({name, status, hours});
      return entries;
    };

    const allEntries = entries.reduce(reducer, []);
    return allEntries;
  };

  checkWeekEntry = () => {
    console.log("javed:: checking entry of week.");
  };
};
